# Sherry QQ头像 · Android v0.1.0-test1

手机上的 QQ 头像制作与 NapCat 上传工具。Android 8.0+，无需 Root。
这是独立工具，**不包含 NapCat、QQ 或 Ubuntu**。请先在同一手机的 AstrBot for Android 中启动 NapCat 并登录 QQ；不需要启动 AstrBot AI 服务。

## 连接与使用

1. 在 NapCat WebUI 的「网络配置」添加并启用 **HTTP 服务器**：host `127.0.0.1`，端口例如 `3000`，设置 Token。已有 WebSocket 连接可以保留。
2. 本工具「连接 QQ」填写 `http://127.0.0.1:3000/`、HTTP 服务 Token、当前登录的 QQ 号，点击测试连接。WebUI 的 6099 等端口不是头像 API；AstrBot 的 WebSocket 6199 也不是。
3. 选择图片或生成全透明头像。PNG/JPEG 默认居中裁成正方形，可调不透明度；原文件模式不作重编码。GIF/APNG 强制原文件模式；动图预览仅显示首帧。
4. 点击上传并核对目标 QQ 号。工具再次调用 `get_login_info`，账号一致才调用 `set_qq_avatar`，图片以 Base64 传给 NapCat，不传 Android 私有文件路径。
5. 在 QQ 中检查实际头像。接口成功不等同于透明度和动画在每个客户端都保留。超时/错误不自动重试，需先检查 QQ 结果。完成后可停止 NapCat。

## 本版功能

- PNG/JPEG 居中方形处理，240/320/640/1024 像素；0–100% 不透明度；全透明 PNG。
- PNG/JPEG/GIF/APNG 原文件传输与导出。
- GIF → APNG：逐帧合成，保留透明区域与有效播放时长，正确处理 GIF 帧处置。使用 Glide gifdecoder 4.16.0；小于 20 ms 的帧时长按解码器规则归一为 100 ms，GIF 未指定循环时播放一次，指定循环时保留循环语义。
- 上传前两次账号核对（手动测试可选，真正上传前始终再次核对），仅访问指定 IPv4 回环 HTTP 服务，不跟随跳转，不使用代理。
- Token 只在内存中，不自动备份、不保存；只保存本机 HTTP 地址。系统文件选择器选图/导出，不申请存储权限。
- 导出本次诊断日志、响应大小上限、超时和失败消息脱敏。

## 限制与实机验证

输入文件最多 8 MiB，宽高最多 4096，GIF/APNG 最多 300 帧；上传最多 3 MiB。
GIF 转换最长边 1024，累计帧像素最多 6400 万，输出最多 32 MiB；超出上传限制的结果仍可导出。
NapCat 普通头像接口不等同于旧工具的 type=90 小世界动态图层。本版不移植 Windows UKey 提取、旧协议、群封面或名片背景。

需要用户实机验证：本机 NapCat 连接、QQ 服务端接受结果、透明/半透明在不同客户端的显示、GIF/APNG 是否动态播放、HyperOS 后台和 Android 17 文件选择器行为。

## 构建和验证

JDK 17、Gradle 8.11.1、Android SDK 35。依赖仅 Glide gifdecoder（含 AndroidX annotations），界面与 HTTP 使用 Android 原生 API。

```sh
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

仓库 `android-apk` 分支的 workflow 自动构建独立 debug APK、运行离线单测与 Android Lint、校验签名和包信息，产物在 Actions 的 Artifacts 中。测试不使用真实 QQ、Token 或腾讯接口。

APK 使用测试签名，非正式商用签名。Actions 缓存尽量保留测试密钥；缓存失效后重建可能需要卸载旧测试 APK，再安装新版本。卸载不会影响外部 NapCat 的 QQ 登录数据。

实现依据：本仓库 `src/QQNTBridge.cs` 的账号核对/上传流程；NapCat 4.18.41 的 `SetQQAvatar.ts` 与 `napcat-common/src/file.ts`；Glide gifdecoder v4.16.0。第三方许可见应用内「诊断 → 第三方许可」。未打包或修改 AstrBot for Android 的代码。
