# v0.1.0-test1 验证结果

GitHub 构建成功：https://github.com/Vanessajeann/qq-avatar-tool-win11/actions/runs/40603066197
构建代码提交：7db27cf（android-apk 分支）。

已通过：Android SDK 35 编译与 APK 打包、7 项 Robolectric 单元测试、Android Lint（0 个错误，仍有非阻断警告）、独立 Pillow GIF/APNG 校验（两组共 7 帧的像素、透明、播放时长、序号与 CRC）、APK v2 签名验证及下载后 SHA256 一致性核验。
此外，本地原始 NapCatClient 对模拟 HTTP 服务的 23 项断言通过。

APK：io.sherry.qqavatar / 0.1.0-test1，minSdk 26，targetSdk 35；仅 INTERNET 权限，无原生 .so。测试签名，支持 Android 8.0+。
SHA256：692561e67a7596c959cc0bf0a29f90c20ab8bdbeac7b56ec2efd52486384fbc6

已查看安卓测试生成的制作头像、连接页面截图。测试没有使用真实 QQ 或腾讯上传接口。
仍待用户实机确认：Android 17/HyperOS 文件选择器、手机 NapCat 连接、QQ 服务端上传结果，以及透明度和动画在各客户端的实际显示。

本源码包的 Android 代码与已验证构建一致，附独立可构建的 Gradle 项目。GitHub 分支以源码归档加工作流保存；工作流展开 android/ 后构建。
