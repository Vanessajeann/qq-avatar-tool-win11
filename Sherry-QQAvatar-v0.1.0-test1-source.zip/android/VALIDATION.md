# v0.1.0-test1 验证状态

## 已执行并通过

- Java 17 解析 4 个 Java 源文件的语法（3 个应用类，1 个 Android 单测类）。这不是 Android SDK 类型检查。
- 4 个 Android XML 文件/资源的 XML 格式检查，以及 GitHub Actions YAML 解析。
- 对原始 `NapCatClient.java` 使用 Java 17 编译；本地测试使用 JSON-java 20250517 解析器，以及仅提供上传大小常量的 ImageTools 编译适配器。无 Android 模拟桩网络实现，HTTP 请求由原始业务类执行。
- 本机模拟 HTTP 服务 23 项断言通过：端点约束、地址归一化、账号不一致无上传、3 MiB 图片逐字节一致、Bearer Token、每次上传前重新核对账号、401、禁止跳转、响应大小上限、HTML/错误 JSON、错误脱敏、失败后不重试、上传大小上限。
- 测试未使用真实 QQ、真实票据或腾讯服务。

## 尚未执行

- Android Gradle 全量编译、APK 打包和签名检查。
- Android Lint、Robolectric 图像/界面测试。
- 独立 Pillow APNG 像素、透明、帧时长、序号与 CRC 校验。
- 实机安装、HyperOS/Android 17 行为和真实 QQ 上传结果验证。

## 构建阻塞

本次环境没有 Android SDK/Gradle，网络无法下载依赖。GitHub 读取正常，但创建分支和创建 Git 树均返回 HTTP 403 `Resource not accessible by integration`；仓库未被修改，云端构建未启动。源码中提供完整 Gradle 项目与 Actions 工作流，恢复仓库写入和 workflow 权限后可继续构建。此压缩包是源码，不是 APK。
