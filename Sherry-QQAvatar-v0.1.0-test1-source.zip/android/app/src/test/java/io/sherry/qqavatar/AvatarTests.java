package io.sherry.qqavatar;

import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.os.Looper;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import com.sun.net.httpserver.*;
import org.json.JSONObject;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w393dp-h851dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class AvatarTests {
    byte[] gif(String name)throws Exception{try(InputStream in=getClass().getResourceAsStream("/"+name+".b64")){return Base64.getMimeDecoder().decode(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));}}
    @Test public void transparencyAndCropAreRealPixels()throws Exception{
        byte[] blank=ImageTools.transparent(320);Bitmap b=BitmapFactory.decodeByteArray(blank,0,blank.length);assertEquals(320,b.getWidth());assertEquals(0,Color.alpha(b.getPixel(100,100)));b.recycle();
        Bitmap src=Bitmap.createBitmap(4,2,Bitmap.Config.ARGB_8888);src.eraseColor(0xffd04080);ByteArrayOutputStream out=new ByteArrayOutputStream();src.compress(Bitmap.CompressFormat.PNG,100,out);src.recycle();
        byte[] half=ImageTools.squarePng(out.toByteArray(),240,50);b=BitmapFactory.decodeByteArray(half,0,half.length);assertEquals(240,b.getWidth());assertEquals(240,b.getHeight());assertTrue(Math.abs(128-Color.alpha(b.getPixel(100,100)))<=1);b.recycle();
        Bitmap first=BitmapFactory.decodeByteArray(half,0,half.length);out.reset();first.compress(Bitmap.CompressFormat.PNG,100,out);first.recycle();
        byte[] quarter=ImageTools.squarePng(out.toByteArray(),240,50);b=BitmapFactory.decodeByteArray(quarter,0,quarter.length);assertTrue(Math.abs(64-Color.alpha(b.getPixel(10,10)))<=1);b.recycle();
    }
    @Test public void invalidPngAndOversizeInputAreRejected()throws Exception{
        byte[] png=ImageTools.transparent(240);png[40]^=1;
        try{ImageTools.inspect(png);fail();}catch(IOException expected){}
        try{ImageTools.readLimited(new ByteArrayInputStream(new byte[20]),10);fail();}catch(IOException expected){}
        try{ImageTools.inspect(new byte[12]);fail();}catch(IOException expected){}
    }
    @Test public void gifToApngRetainsFramesAndProducesIndependentFixtures()throws Exception{
        Path qa=Paths.get("build/qa");Files.createDirectories(qa);
        for(String name:new String[]{"test.gif","partial.gif"}){
            byte[] input=gif(name);ImageTools.Info original=ImageTools.inspect(input);byte[] apng=ImageTools.gifToApng(input);ImageTools.Info converted=ImageTools.inspect(apng);
            assertEquals("APNG",converted.format);assertEquals(original.frames,converted.frames);assertEquals(original.width,converted.width);assertEquals(original.height,converted.height);
            Files.write(qa.resolve(name),input);Files.write(qa.resolve(name+".png"),apng);
            try{ImageTools.squarePng(input,320,50);fail("must not flatten animation");}catch(IOException expected){}
        }
    }
    @Test public void endpointAndErrorsCannotLeakTokensOrImageData()throws Exception{
        assertEquals("127.0.0.1",NapCatClient.validateEndpoint("http://127.0.0.1:3000").getHost());
        for(String s:new String[]{"http://127.0.0.1.evil:3000/","https://127.0.0.1:3000/","http://localhost:3000/","http://user@127.0.0.1:3000/","http://127.0.0.1:3000/set_qq_avatar","http://127.0.0.1:3000/?token=x","http://127.0.0.1:0/","http://127.0.0.1:65536/"}){
            try{NapCatClient.validateEndpoint(s);fail(s);}catch(IOException expected){}
        }
        String safe=NapCatClient.safeMessage("private-token avatar base64://QUJDREVGRw== failed","private-token");assertFalse(safe.contains("private-token"));assertFalse(safe.contains("QUJDREVGRw"));
    }
    static void response(HttpExchange x,int status,String text)throws IOException{byte[] bytes=text.getBytes(java.nio.charset.StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type","application/json");x.sendResponseHeaders(status,bytes.length);x.getResponseBody().write(bytes);x.close();}
    @Test public void bridgeChecksAccountAndPreservesImageBytes()throws Exception{
        AtomicInteger uploads=new AtomicInteger();byte[] image=ImageTools.transparent(240);String[] actual={"10001"};
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/get_login_info",x->{assertEquals("Bearer unit-token",x.getRequestHeaders().getFirst("Authorization"));response(x,200,"{\"status\":\"ok\",\"retcode\":0,\"data\":{\"user_id\":\""+actual[0]+"\"}}");});
        server.createContext("/set_qq_avatar",x->{try{String body=new String(x.getRequestBody().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);String file=new JSONObject(body).getString("file");assertTrue(file.startsWith("base64://"));assertArrayEquals(image,Base64.getDecoder().decode(file.substring(9)));uploads.incrementAndGet();response(x,200,"{\"status\":\"ok\",\"retcode\":0,\"data\":null}");}catch(Exception e){throw new IOException(e);}});
        server.start();try{
            NapCatClient c=new NapCatClient("http://127.0.0.1:"+server.getAddress().getPort()+"/","unit-token");
            try{c.upload("10002",image);fail();}catch(IOException expected){}assertEquals(0,uploads.get());
            c.upload("10001",image);assertEquals(1,uploads.get());actual[0]="10003";
            try{c.upload("10001",image);fail();}catch(IOException expected){}assertEquals(1,uploads.get());
        }finally{server.stop(0);}
    }
    @Test public void bridgeRejectsRedirectAndLargeResponses()throws Exception{
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);AtomicInteger hits=new AtomicInteger();
        server.createContext("/get_login_info",x->{x.getResponseHeaders().set("Location","/should-not-visit");response(x,302,"{}");});
        server.createContext("/should-not-visit",x->{hits.incrementAndGet();response(x,200,"{}");});server.start();
        try{NapCatClient c=new NapCatClient("http://127.0.0.1:"+server.getAddress().getPort()+"/","");try{c.checkAccount("10001");fail();}catch(IOException expected){}assertEquals(0,hits.get());}
        finally{server.stop(0);}
        server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.createContext("/get_login_info",x->response(x,200,"x".repeat(1024*1024+1)));server.start();
        try{NapCatClient c=new NapCatClient("http://127.0.0.1:"+server.getAddress().getPort()+"/","");try{c.checkAccount("10001");fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("响应过大"));}}
        finally{server.stop(0);}
    }
    @Test public void activityRendersWithAllThreePages()throws Exception{
        var ctl=Robolectric.buildActivity(MainActivity.class).setup();MainActivity a=ctl.get();
        try{assertNotNull(a.preview);assertEquals("http://127.0.0.1:3000/",a.endpoint.getText().toString());
            View view=a.getWindow().getDecorView();Path qa=Paths.get("build/qa");Files.createDirectories(qa);
            for(int p=0;p<3;p++){a.page(p);view.measure(View.MeasureSpec.makeMeasureSpec(393,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(851,View.MeasureSpec.EXACTLY));view.layout(0,0,393,851);Bitmap b=Bitmap.createBitmap(393,851,Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));try(OutputStream out=Files.newOutputStream(qa.resolve("screen-"+p+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
        }finally{ctl.pause().stop().destroy();}
    }
}
