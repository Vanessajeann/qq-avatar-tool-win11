package io.sherry.qqavatar;

import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.os.Looper;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import okhttp3.mockwebserver.*;
import org.json.JSONObject;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w393dp-h851dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class AvatarTests {
    byte[] gif(String name)throws Exception{try(InputStream in=getClass().getResourceAsStream("/"+name+".b64")){return Base64.getMimeDecoder().decode(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));}}
    @Test public void transparencyAndCropAreRealPixels()throws Exception{
        byte[] blank=ImageTools.transparent(320);Bitmap b=BitmapFactory.decodeByteArray(blank,0,blank.length);assertEquals(320,b.getWidth());assertEquals(0,Color.alpha(b.getPixel(100,100)));b.recycle();
        Bitmap src=Bitmap.createBitmap(4,2,Bitmap.Config.ARGB_8888);src.eraseColor(0xffd04080);ByteArrayOutputStream out=new ByteArrayOutputStream();src.compress(Bitmap.CompressFormat.PNG,100,out);src.recycle();
        byte[] half=ImageTools.squarePng(out.toByteArray(),240,50);b=BitmapFactory.decodeByteArray(half,0,half.length);assertEquals(240,b.getWidth());assertEquals(240,b.getHeight());assertTrue(Math.abs(128-Color.alpha(b.getPixel(100,100)))<=1);b.recycle();
        Bitmap first=BitmapFactory.decodeByteArray(half,0,half.length);out.reset();first.compress(Bitmap.CompressFormat.PNG,100,out);first.recycle();
        byte[] quarter=ImageTools.squarePng(out.toByteArray(),240,50);b=BitmapFactory.decodeByteArray(quarter,0,quarter.length);assertTrue(Math.abs(64-Color.alpha(b.getPixel(10,10)))<=1);b.recycle();
    }
    @Test public void invalidPngAndOversizeInputAreRejected()throws Exception{
        byte[] png=ImageTools.transparent(240);png[40]^=1;
        try{ImageTools.inspect(png);fail();}catch(IOException expected){}
        try{ImageTools.readLimited(new ByteArrayInputStream(new byte[20]),10);fail();}catch(IOException expected){}
        try{ImageTools.inspect(new byte[12]);fail();}catch(IOException expected){}
    }
    @Test public void gifToApngRetainsFramesAndProducesIndependentFixtures()throws Exception{
        Path qa=Paths.get("build/qa");Files.createDirectories(qa);
        for(String name:new String[]{"test.gif","partial.gif"}){
            byte[] input=gif(name);ImageTools.Info original=ImageTools.inspect(input);byte[] apng=ImageTools.gifToApng(input);ImageTools.Info converted=ImageTools.inspect(apng);
            assertEquals("APNG",converted.format);assertEquals(original.frames,converted.frames);assertEquals(original.width,converted.width);assertEquals(original.height,converted.height);
            Files.write(qa.resolve(name),input);Files.write(qa.resolve(name+".png"),apng);
            try{ImageTools.squarePng(input,320,50);fail("must not flatten animation");}catch(IOException expected){}
        }
    }
    @Test public void endpointAndErrorsCannotLeakTokensOrImageData()throws Exception{
        assertEquals("127.0.0.1",NapCatClient.validateEndpoint("http://127.0.0.1:3000").getHost());
        for(String s:new String[]{"http://127.0.0.1.evil:3000/","https://127.0.0.1:3000/","http://localhost:3000/","http://user@127.0.0.1:3000/","http://127.0.0.1:3000/set_qq_avatar","http://127.0.0.1:3000/?token=x","http://127.0.0.1:0/","http://127.0.0.1:65536/"}){
            try{NapCatClient.validateEndpoint(s);fail(s);}catch(IOException expected){}
        }
        String safe=NapCatClient.safeMessage("private-token avatar base64://QUJDREVGRw== failed","private-token");assertFalse(safe.contains("private-token"));assertFalse(safe.contains("QUJDREVGRw"));
    }
    static MockResponse ok(String body){return new MockResponse().setHeader("Content-Type","application/json").setBody(body);}
    static MockResponse login(String id){return ok("{\"status\":\"ok\",\"retcode\":0,\"data\":{\"user_id\":\""+id+"\"}}");}
    @Test public void bridgeChecksAccountAndPreservesImageBytes()throws Exception{
        byte[] image=ImageTools.transparent(240);MockWebServer server=new MockWebServer();server.start();
        try{
            NapCatClient c=new NapCatClient("http://127.0.0.1:"+server.getPort()+"/","unit-token");
            server.enqueue(login("10001"));
            try{c.upload("10002",image);fail();}catch(IOException expected){}
            assertEquals(1,server.getRequestCount());assertEquals("/get_login_info",server.takeRequest().getPath());
            server.enqueue(login("10001"));server.enqueue(ok("{\"status\":\"ok\",\"retcode\":0,\"data\":null}"));
            c.upload("10001",image);RecordedRequest check=server.takeRequest();assertEquals("Bearer unit-token",check.getHeader("Authorization"));
            RecordedRequest request=server.takeRequest();assertEquals("/set_qq_avatar",request.getPath());
            String file=new JSONObject(request.getBody().readUtf8()).getString("file");assertTrue(file.startsWith("base64://"));assertArrayEquals(image,Base64.getDecoder().decode(file.substring(9)));
            server.enqueue(login("10003"));try{c.upload("10001",image);fail();}catch(IOException expected){}
            assertEquals("/get_login_info",server.takeRequest().getPath());assertEquals(4,server.getRequestCount());
        }finally{server.shutdown();}
    }
    @Test public void bridgeRejectsRedirectAndLargeResponses()throws Exception{
        MockWebServer server=new MockWebServer();server.start();
        try{
            NapCatClient c=new NapCatClient("http://127.0.0.1:"+server.getPort()+"/","");
            server.enqueue(new MockResponse().setResponseCode(302).setHeader("Location","/should-not-visit"));
            try{c.checkAccount("10001");fail();}catch(IOException expected){}assertEquals(1,server.getRequestCount());
            server.enqueue(ok("x".repeat(1024*1024+1)));
            try{c.checkAccount("10001");fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("响应过大"));}assertEquals(2,server.getRequestCount());
        }finally{server.shutdown();}
    }
    ConnectionStore testStore(android.content.SharedPreferences prefs)throws Exception{
        javax.crypto.KeyGenerator generator=javax.crypto.KeyGenerator.getInstance("AES");generator.init(256);
        final javax.crypto.SecretKey[] key={generator.generateKey()};
        return new ConnectionStore(prefs,new ConnectionStore.Keys(){public javax.crypto.SecretKey get(boolean create)throws Exception{if(key[0]==null&&create)key[0]=generator.generateKey();return key[0];}public void delete(){key[0]=null;}});
    }
    @Test public void rememberIsOptInAndClearRemovesAllSavedValues()throws Exception{
        var prefs=RuntimeEnvironment.getApplication().getSharedPreferences("remember-test",0);prefs.edit().clear().commit();ConnectionStore store=testStore(prefs);
        ConnectionStore.Data data=new ConnectionStore.Data("http://127.0.0.1:3000/","unit-secret-token","10001");
        store.save(data);assertTrue(prefs.getAll().isEmpty());assertNull(store.load());
        store.enable();store.save(data);assertEquals("unit-secret-token",store.load().token);
        assertFalse(prefs.getString("sealed","").contains("unit-secret-token"));assertFalse(prefs.getString("sealed","").contains("10001"));
        store.clear();assertFalse(store.enabled());assertNull(store.load());assertTrue(prefs.getAll().isEmpty());
        store.save(data);assertTrue(prefs.getAll().isEmpty());
    }
    @Test public void savedConnectionAuthenticatesAndUsesFreshIv()throws Exception{
        var prefs=RuntimeEnvironment.getApplication().getSharedPreferences("encrypt-test",0);prefs.edit().clear().commit();ConnectionStore store=testStore(prefs);
        store.enable();ConnectionStore.Data data=new ConnectionStore.Data("http://127.0.0.1:3001/","private-value","10002");store.save(data);
        String first=prefs.getString("sealed","");store.save(data);String second=prefs.getString("sealed","");assertNotEquals(first,second);
        ConnectionStore.Data restored=store.load();assertEquals(data.endpoint,restored.endpoint);assertEquals(data.account,restored.account);assertEquals(data.token,restored.token);
        JSONObject envelope=new JSONObject(second);byte[] encrypted=Base64.getDecoder().decode(envelope.getString("data"));encrypted[0]^=1;envelope.put("data",Base64.getEncoder().encodeToString(encrypted));prefs.edit().putString("sealed",envelope.toString()).commit();
        try{store.load();fail("tampered ciphertext accepted");}catch(javax.crypto.AEADBadTagException expected){}
        store.clear();
    }
    @Test public void motionPolicyReducesIdleAndPowerSaverWork(){
        assertEquals(33,MotionPolicy.delay(10000,9500,false,true));assertEquals(200,MotionPolicy.delay(10000,8000,false,true));
        assertEquals(100,MotionPolicy.delay(10000,9500,true,true));assertEquals(500,MotionPolicy.delay(10000,8000,true,true));
        assertEquals(-1,MotionPolicy.delay(10000,9500,false,false));
    }
    @Test @Config(sdk={28,35}) public void activityRendersWithAllThreePages()throws Exception{
        var ctl=Robolectric.buildActivity(MainActivity.class).setup();MainActivity a=ctl.get();
        try{assertNotNull(a.preview);assertEquals("http://127.0.0.1:3000/",a.endpoint.getText().toString());
            View view=a.getWindow().getDecorView();Path qa=Paths.get("build/qa");Files.createDirectories(qa);
            for(int p=0;p<3;p++){a.page(p);view.measure(View.MeasureSpec.makeMeasureSpec(393,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(851,View.MeasureSpec.EXACTLY));view.layout(0,0,393,851);if(android.os.Build.VERSION.SDK_INT>=29){RenderNode node=new RenderNode("glass-preview");node.setPosition(0,0,393,851);view.draw(node.beginRecording(393,851));node.endRecording();assertTrue(node.hasDisplayList());}Bitmap b=Bitmap.createBitmap(393,851,Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));try(OutputStream out=Files.newOutputStream(qa.resolve("screen-"+android.os.Build.VERSION.SDK_INT+"-"+p+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
        }finally{ctl.pause().stop().destroy();}
    }
}
