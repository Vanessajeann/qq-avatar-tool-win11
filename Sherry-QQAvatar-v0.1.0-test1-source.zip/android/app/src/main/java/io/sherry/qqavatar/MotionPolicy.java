package io.sherry.qqavatar;

/** Milliseconds until next visual refresh; -1 means no continuous animation. */
public final class MotionPolicy {
    private MotionPolicy(){}
    public static long delay(long now,long lastInteraction,boolean powerSave,boolean animationsEnabled){
        if(!animationsEnabled)return -1;
        boolean active=now-lastInteraction<1200;
        return powerSave?(active?100:500):(active?33:200);
    }
}
