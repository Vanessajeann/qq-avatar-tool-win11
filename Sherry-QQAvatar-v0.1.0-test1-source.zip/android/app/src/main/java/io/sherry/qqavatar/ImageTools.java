package io.sherry.qqavatar;

import android.graphics.*;
import com.bumptech.glide.gifdecoder.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.CRC32;

public final class ImageTools {
    public static final int MAX_INPUT=8*1024*1024, MAX_UPLOAD=3*1024*1024, MAX_EXPORT=32*1024*1024;
    public static final class Info {
        public final String format; public final int width,height,frames;
        Info(String f,int w,int h,int n){format=f;width=w;height=h;frames=n;}
        public boolean animated(){return frames>1 || format.equals("APNG");}
        public String summary(){return format+" · "+width+" × "+height+(animated()?" · "+frames+" 帧":"");}
    }
    public static byte[] readLimited(InputStream in,int limit) throws IOException {
        if(in==null)throw new IOException("无法读取所选文件。");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1){if(out.size()+n>limit)throw new IOException("文件超过大小限制，请先缩小图片。");out.write(b,0,n);}return out.toByteArray();
    }
    public static Info inspect(byte[] bytes) throws IOException {
        if(bytes==null||bytes.length<10||bytes.length>MAX_EXPORT)throw new IOException("图片为空、已损坏或超过 32 MiB。");
        if(isGif(bytes)){
            GifHeaderParser p=new GifHeaderParser(); GifHeader h;
            try{h=p.setData(bytes).parseHeader();}catch(RuntimeException e){throw new IOException("GIF 文件损坏。");}finally{p.clear();}
            if(h.getStatus()!=GifDecoder.STATUS_OK || h.getNumFrames()<1)throw new IOException("GIF 无法解析。");
            dimensions(h.getWidth(),h.getHeight());
            if(h.getNumFrames()>300)throw new IOException("GIF 超过 300 帧。");
            return new Info("GIF",h.getWidth(),h.getHeight(),h.getNumFrames());
        }
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
        BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);dimensions(o.outWidth,o.outHeight);
        if(isPng(bytes)){
            int n=1;boolean apng=false;boolean end=false;
            for(int pos=8;pos+12<=bytes.length;){
                int len=readInt(bytes,pos); if(len<0||len>bytes.length-pos-12)throw new IOException("PNG 数据块长度无效。");
                CRC32 crc=new CRC32();crc.update(bytes,pos+4,len+4);
                if((int)crc.getValue()!=readInt(bytes,pos+8+len))throw new IOException("PNG 数据块校验失败。");
                String type=new String(bytes,pos+4,4,StandardCharsets.US_ASCII);
                if(type.equals("acTL")){if(len!=8)throw new IOException("APNG 头无效。");n=readInt(bytes,pos+8);apng=true;}
                pos+=len+12;if(type.equals("IEND")){end=true;break;}
            }
            if(!end||n<1||n>300)throw new IOException("PNG/APNG 不完整或超过 300 帧。");
            return new Info(apng?"APNG":"PNG",o.outWidth,o.outHeight,n);
        }
        if(bytes[0]==(byte)0xff&&bytes[1]==(byte)0xd8)return new Info("JPEG",o.outWidth,o.outHeight,1);
        throw new IOException("目前支持 PNG、JPEG、GIF 和 APNG。");
    }
    private static void dimensions(int w,int h)throws IOException{if(w<1||h<1||w>4096||h>4096||(long)w*h>16_777_216)throw new IOException("图片尺寸须在 4096 × 4096 以内。");}
    public static boolean isPng(byte[] b){return b.length>8&&b[0]==(byte)137&&b[1]==80&&b[2]==78&&b[3]==71&&b[4]==13&&b[5]==10&&b[6]==26&&b[7]==10;}
    public static boolean isGif(byte[] b){return b.length>6&&(new String(b,0,6,StandardCharsets.US_ASCII).equals("GIF89a")||new String(b,0,6,StandardCharsets.US_ASCII).equals("GIF87a"));}
    public static Bitmap preview(byte[] bytes)throws IOException{
        BitmapFactory.Options o=new BitmapFactory.Options();o.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Info i=inspect(bytes);int largest=Math.max(i.width,i.height);
        // inSampleSize defaults to 0; explicitly compute a safe display sample.
        o.inSampleSize=1;while(largest/o.inSampleSize>1024)o.inSampleSize*=2;
        Bitmap b=BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);if(b==null)throw new IOException("无法解码图片预览。");return b;
    }
    public static byte[] transparent(int size)throws IOException{
        Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);try{return png(b);}finally{b.recycle();}
    }
    public static byte[] squarePng(byte[] bytes,int size,int opacity)throws IOException{
        Info info=inspect(bytes);if(info.animated())throw new IOException("动图请使用原文件模式，避免丢失动画。");
        if(size<1||size>1024||opacity<0||opacity>100)throw new IOException("图片参数无效。");
        Bitmap src=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(src==null)throw new IOException("无法解码图片。");
        Bitmap dst=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
        try{
            int side=Math.min(src.getWidth(),src.getHeight()),left=(src.getWidth()-side)/2,top=(src.getHeight()-side)/2;
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);paint.setAlpha(Math.round(opacity*255f/100));
            new Canvas(dst).drawBitmap(src,new Rect(left,top,left+side,top+side),new Rect(0,0,size,size),paint);return png(dst);
        }finally{src.recycle();dst.recycle();}
    }
    private static byte[] png(Bitmap b)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();if(!b.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("PNG 编码失败。");return out.toByteArray();}
    public static String hash(byte[] bytes){try{byte[] h=MessageDigest.getInstance("SHA-256").digest(bytes);StringBuilder s=new StringBuilder();for(byte b:h)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}catch(Exception e){return "unavailable";}}
    private static int readInt(byte[] b,int p){return ByteBuffer.wrap(b,p,4).getInt();}
    private static void chunk(DataOutputStream out,String type,byte[] bytes)throws IOException{
        byte[] name=type.getBytes(StandardCharsets.US_ASCII);out.writeInt(bytes.length);out.write(name);out.write(bytes);
        CRC32 crc=new CRC32();crc.update(name);crc.update(bytes);out.writeInt((int)crc.getValue());
    }
    /** Full composed GIF frames become APNG SOURCE frames; decoder handles GIF disposal. */
    public static byte[] gifToApng(byte[] bytes)throws IOException{
        Info i=inspect(bytes);if(!i.format.equals("GIF"))throw new IOException("请先选择 GIF。");
        if(i.width>1024||i.height>1024||(long)i.width*i.height*i.frames>64_000_000)throw new IOException("转换限制：最长边 1024，总帧像素不超过 6400 万。可改用原 GIF 上传。");
        GifHeaderParser parser=new GifHeaderParser();GifHeader header=parser.setData(bytes).parseHeader();parser.clear();
        GifDecoder.BitmapProvider provider=new GifDecoder.BitmapProvider(){
            public Bitmap obtain(int w,int h,Bitmap.Config config){return Bitmap.createBitmap(w,h,config);}
            public void release(Bitmap b){b.recycle();}public byte[] obtainByteArray(int n){return new byte[n];}
            public void release(byte[] b){}public int[] obtainIntArray(int n){return new int[n];}public void release(int[] b){}
        };
        StandardGifDecoder dec=new StandardGifDecoder(provider,header,ByteBuffer.wrap(bytes));dec.setDefaultBitmapConfig(Bitmap.Config.ARGB_8888);
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);int sequence=0;
        try{
            out.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
            chunk(out,"IHDR",ByteBuffer.allocate(13).putInt(i.width).putInt(i.height).put((byte)8).put((byte)6).put(new byte[3]).array());
            chunk(out,"acTL",ByteBuffer.allocate(8).putInt(i.frames).putInt(dec.getTotalIterationCount()).array());
            for(int f=0;f<i.frames;f++){
                if(Thread.currentThread().isInterrupted())throw new IOException("转换已停止。");
                dec.advance();Bitmap frame=dec.getNextFrame();
                if(frame==null||dec.getStatus()!=GifDecoder.STATUS_OK){if(frame!=null)frame.recycle();throw new IOException("GIF 帧解码失败。");}
                byte[] data;try{data=png(frame);}finally{frame.recycle();}
                int delay=dec.getNextDelay(); // Glide normalizes <20 ms to 100 ms, as browser playback does.
                chunk(out,"fcTL",ByteBuffer.allocate(26).putInt(sequence++).putInt(i.width).putInt(i.height).putInt(0).putInt(0).putShort((short)(delay/10)).putShort((short)100).put((byte)0).put((byte)0).array());
                for(int p=8;p+12<=data.length;){int len=readInt(data,p);String type=new String(data,p+4,4,StandardCharsets.US_ASCII);
                    if(type.equals("IDAT")){
                        byte[] payload=Arrays.copyOfRange(data,p+8,p+8+len);
                        if(f==0)chunk(out,"IDAT",payload);else chunk(out,"fdAT",ByteBuffer.allocate(len+4).putInt(sequence++).put(payload).array());
                    }p+=len+12;
                }
                if(buffer.size()>MAX_EXPORT)throw new IOException("转换结果超过 32 MiB，请缩小 GIF。");
            }
            chunk(out,"IEND",new byte[0]);return buffer.toByteArray();
        }finally{dec.clear();}
    }
}
