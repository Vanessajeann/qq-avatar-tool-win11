package io.sherry.qqavatar;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int PICK=10,EXPORT_IMAGE=11,EXPORT_LOG=12;
    static final int INK=0xff342d34,MUTED=0xff81737c,ACCENT=0xffa35070,BG=0xfffaf6f4;
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    final ArrayList<View> controls=new ArrayList<>();
    final StringBuilder history=new StringBuilder();
    LinearLayout root,body,imagePage,connectionPage,logPage;
    TextView status,details,opacityLabel,logText,connectionStatus;
    EditText endpoint,token,account; SeekBar opacity; Spinner sizes; CheckBox original;
    ImageView preview; ProgressBar progress;
    byte[] source,prepared,pendingExport; ImageTools.Info info; boolean busy,destroyed,binding;
    String exportName="avatar.png",exportMime="image/png";
    int size(){return new int[]{240,320,640,1024}[sizes.getSelectedItemPosition()];}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(BG);
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);
        root.setPadding(dp(20),dp(12),dp(20),0);
        if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.ime());
            v.setPadding(dp(20)+bars.left,dp(12)+bars.top,dp(20)+bars.right,bars.bottom);return insets;});
        TextView brand=text("SHERRY  /  QQ AVATAR",12,ACCENT);brand.setLetterSpacing(.14f);root.addView(brand);
        root.addView(text("让头像，轻一点",28,INK));
        root.addView(text("透明 · 半透明 · 动态原图",14,MUTED));
        status=text("先启动 NapCat，再连接你的 QQ",13,ACCENT);status.setPadding(0,dp(12),0,dp(8));root.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));
        LinearLayout tabs=new LinearLayout(this);root.addView(tabs);
        tabs.addView(button("制作头像",()->page(0)),new LinearLayout.LayoutParams(0,dp(48),1));
        tabs.addView(button("连接 QQ",()->page(1)),new LinearLayout.LayoutParams(0,dp(48),1));
        tabs.addView(button("诊断",()->page(2)),new LinearLayout.LayoutParams(0,dp(48),1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,dp(12),0,dp(20));scroll.addView(body);
        imagePage=column();connectionPage=column();logPage=column();body.addView(imagePage);body.addView(connectionPage);body.addView(logPage);
        createImages();createConnection();createLogs();setContentView(root);root.requestApplyInsets();page(0);
        log("Sherry QQ头像 "+BuildConfig.VERSION_NAME+"；Android API "+Build.VERSION.SDK_INT+"。");
        log("本版连接外部 NapCat，不包含 QQ 登录环境。Token 仅保留在内存。");
    }
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout card(LinearLayout parent){LinearLayout l=column();l.setPadding(dp(18),dp(16),dp(18),dp(16));l.setBackground(round(0xffffffff,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);parent.addView(l,p);return l;}
    TextView text(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(dp(3),1);return t;}
    Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(ACCENT);b.setAllCaps(false);b.setOnClickListener(v->action.run());controls.add(b);return b;}
    void title(LinearLayout p,String s){TextView t=text(s,18,INK);t.setTypeface(null,1);t.setPadding(0,0,0,dp(10));p.addView(t);}
    EditText field(LinearLayout p,String hint,int input){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine();e.setInputType(input);p.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));controls.add(e);return e;}
    void createImages(){
        LinearLayout c=card(imagePage);title(c,"01  选择与预览");
        preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.setBackground(new Checkerboard());
        c.addView(preview,new LinearLayout.LayoutParams(-1,dp(230)));
        details=text("选择一张图片开始；棋盘格表示透明区域。",13,MUTED);details.setPadding(0,dp(10),0,dp(10));c.addView(details);
        c.addView(button("从手机选择图片",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}));
        c.addView(button("生成全透明头像",()->generateTransparent()));
        LinearLayout edit=card(imagePage);title(edit,"02  调整与导出");
        edit.addView(text("静态图片居中裁成正方形；动图原文件上传。",13,MUTED));
        sizes=new Spinner(this);sizes.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"240 × 240","320 × 320（推荐）","640 × 640","1024 × 1024"}));sizes.setSelection(1);edit.addView(sizes);controls.add(sizes);
        sizes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(source!=null&&!busy&&!binding)refresh();}public void onNothingSelected(AdapterView<?> p){}});
        opacityLabel=text("不透明度 100%",14,INK);edit.addView(opacityLabel);
        opacity=new SeekBar(this);opacity.setMax(100);opacity.setProgress(100);edit.addView(opacity);controls.add(opacity);
        opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int n,boolean user){opacityLabel.setText("不透明度 "+n+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){refresh();}});
        original=new CheckBox(this);original.setText("原文件模式（保留 GIF / APNG 动画）");original.setTextSize(14);edit.addView(original);controls.add(original);
        original.setOnCheckedChangeListener((b,on)->{if(binding)return;if(info!=null&&info.animated()&&!on){original.setChecked(true);toast("动图需保留原文件，或使用 GIF → APNG 转换。");return;}updateEnabled();if(source!=null&&!busy&&!binding)refresh();});
        edit.addView(button("GIF → APNG",()->convertGif()));
        edit.addView(button("导出当前图片",()->exportImage()));
        LinearLayout upload=card(imagePage);title(upload,"03  上传到 QQ");
        upload.addView(text("使用连接页填写的账号。上传前会再次核对 NapCat 登录账号。",13,MUTED));
        Button send=button("核对账号并上传",()->confirmUpload());send.setTextColor(0xffffffff);send.setBackground(round(ACCENT,12));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(52));sp.topMargin=dp(12);upload.addView(send,sp);
        upload.addView(text("普通头像接口的透明和动画效果，以 QQ 实际显示为准。",12,MUTED));
    }
    void createConnection(){
        LinearLayout c=card(connectionPage);title(c,"连接本机 NapCat");
        c.addView(text("在 AstrBot for Android 启动 NapCat 并登录 QQ。AstrBot 的 AI 服务无需启动。",14,INK));
        c.addView(text("进入 NapCat 后台 → 网络配置 → 添加 HTTP 服务器。主机填 127.0.0.1，端口可用 3000，设置 Token 并启用。",14,MUTED));
        endpoint=field(c,"OneBot HTTP 地址",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        endpoint.setText(getPreferences(0).getString("endpoint","http://127.0.0.1:3000/"));
        token=field(c,"HTTP 服务 Token（不是 WebUI 口令）",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);token.setSaveEnabled(false);token.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        account=field(c,"要更换头像的 QQ 号",InputType.TYPE_CLASS_NUMBER);account.setSaveEnabled(false);
        connectionStatus=text("尚未核对账号",13,MUTED);c.addView(connectionStatus);
        c.addView(button("测试连接并核对账号",()->checkConnection()));
        LinearLayout guide=card(connectionPage);title(guide,"使用提示");
        guide.addView(text("• 地址填写 HTTP 服务器端口，不能使用 6099 等 WebUI 端口。\n• 两个应用都运行在当前手机；图片通过接口传输，不依赖共享目录。\n• 本工具不需要 Root、UKey 或存储权限。\n• 更换头像完成后可停止 NapCat，无需长期挂后台。\n• Token 不写入配置或诊断文件，关闭进程后需要重新填写。",14,MUTED));
    }
    void createLogs(){
        LinearLayout c=card(logPage);title(c,"本次运行记录");
        c.addView(text("日志不记录 Token、图片内容、文件路径或完整 QQ 号。可以导出后发给我分析。",13,MUTED));
        logText=text("",12,INK);logText.setTypeface(android.graphics.Typeface.MONOSPACE);logText.setTextIsSelectable(true);c.addView(logText);
        c.addView(button("导出诊断 .txt",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"Sherry-QQAvatar-diagnostic.txt");startActivityForResult(i,EXPORT_LOG);}));
        c.addView(button("清空本次日志",()->{history.setLength(0);logText.setText("");}));
        LinearLayout about=card(logPage);title(about,"关于这个版本");
        about.addView(text("v"+BuildConfig.VERSION_NAME+" · 独立头像工具\nPNG / JPEG 透明度与方形处理；GIF / APNG 原文件传输；GIF 转 APNG。\n动图预览只显示首帧。GIF 转换采用 Glide gifdecoder 4.16.0；极短帧时长按解码器播放规则处理。\n不包含旧 UKey、群封面或小世界动态图层上传。",13,MUTED));
        about.addView(button("第三方许可",()->showLicense()));
    }
    void page(int n){imagePage.setVisibility(n==0?View.VISIBLE:View.GONE);connectionPage.setVisibility(n==1?View.VISIBLE:View.GONE);logPage.setVisibility(n==2?View.VISIBLE:View.GONE);}
    void updateEnabled(){for(View v:controls)v.setEnabled(!busy);if(original!=null){opacity.setEnabled(!busy&&!original.isChecked());sizes.setEnabled(!busy&&!original.isChecked());}}
    void setBusy(boolean value,String message){busy=value;updateEnabled();progress.setVisibility(value?View.VISIBLE:View.GONE);status.setText(message);}
    interface Work<T>{T run()throws Exception;}interface Done<T>{void accept(T t)throws Exception;}
    <T>void task(String label,Work<T> work,Done<T> done){
        if(busy)return;setBusy(true,label);
        worker.execute(()->{try{T result=work.run();runOnUiThread(()->{if(destroyed)return;setBusy(false,"已完成");try{done.accept(result);}catch(Exception e){failure(e);}});}catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(destroyed)return;setBusy(false,"操作未完成");failure(e);});}});
    }
    void failure(Throwable e){String m=e instanceof OutOfMemoryError?"图片处理内存不足，请缩小图片后重试。":NapCatClient.safeMessage(e.getMessage(),token==null?"":token.getText().toString().trim());
        if(account!=null&&!account.getText().toString().isEmpty())m=m.replace(account.getText().toString(),"[QQ 号已隐藏]");
        log(m);new AlertDialog.Builder(this).setTitle("操作未完成").setMessage(m+"\n\n若刚执行了上传，请先在 QQ 核对结果，再决定是否重试。").setPositiveButton("知道了",null).show();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void log(String s){String stamp=new SimpleDateFormat("HH:mm:ss",Locale.ROOT).format(new Date());history.append(stamp).append("  ").append(s).append('\n');if(history.length()>24000)history.delete(0,history.length()-20000);if(logText!=null)logText.setText(history.toString());}
    void refresh(){
        if(source==null||busy)return;
        final byte[] input=source;final boolean keep=original.isChecked();final int edge=size(),alpha=opacity.getProgress();
        task("正在处理预览…",()->keep?input:ImageTools.squarePng(input,edge,alpha),bytes->{prepared=bytes;display(bytes);});
    }
    void display(byte[] bytes)throws IOException{
        android.graphics.drawable.Drawable old=preview.getDrawable();Bitmap b=ImageTools.preview(bytes);preview.setImageBitmap(b);
        if(old instanceof BitmapDrawable){Bitmap previous=((BitmapDrawable)old).getBitmap();if(previous!=b&&!previous.isRecycled())previous.recycle();}
        ImageTools.Info out=ImageTools.inspect(bytes);details.setText(out.summary()+" · "+String.format(Locale.ROOT,"%.1f KiB",bytes.length/1024f)+(out.animated()?"\n动图预览显示首帧":"")+(bytes.length>ImageTools.MAX_UPLOAD?"\n超过 3 MiB：可以导出，暂不能上传":""));status.setText("图片已准备好");
    }
    void generateTransparent(){final int edge=size();task("正在生成透明图片…",()->ImageTools.transparent(edge),bytes->{source=prepared=bytes;info=ImageTools.inspect(bytes);binding=true;original.setChecked(false);opacity.setProgress(100);binding=false;updateEnabled();display(bytes);log("生成全透明 PNG，"+edge+" × "+edge+"。");});}
    void convertGif(){
        if(source==null||info==null||!info.format.equals("GIF")){toast("请先选择 GIF 图片。");return;}
        final byte[] bytes=source;task("正在转换 GIF → APNG…",()->ImageTools.gifToApng(bytes),out->{source=prepared=out;info=ImageTools.inspect(out);binding=true;original.setChecked(true);binding=false;updateEnabled();display(out);log("GIF 转 APNG："+info.summary()+"；"+out.length+" 字节。");});
    }
    void exportImage(){
        if(prepared==null){toast("请先选择并处理图片。");return;}
        pendingExport=prepared;try{ImageTools.Info out=ImageTools.inspect(prepared);String ext=out.format.equals("GIF")?"gif":out.format.equals("JPEG")?"jpg":"png";
            exportName="Sherry-avatar."+ext;exportMime=ext.equals("jpg")?"image/jpeg":ext.equals("gif")?"image/gif":"image/png";
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType(exportMime);i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,exportName);startActivityForResult(i,EXPORT_IMAGE);
        }catch(Exception e){failure(e);}
    }
    NapCatClient client()throws IOException{return new NapCatClient(endpoint.getText().toString(),token.getText().toString());}
    void checkConnection(){
        try{NapCatClient c=client();String uin=account.getText().toString().trim();task("正在连接并核对账号…",()->c.checkAccount(uin),id->{getPreferences(0).edit().putString("endpoint",endpoint.getText().toString().trim()).apply();connectionStatus.setText("连接成功，账号核对一致");status.setText("NapCat 已连接");log("OneBot HTTP 连接成功；账号核对一致。");});}catch(Exception e){failure(e);}
    }
    void confirmUpload(){
        if(prepared==null){toast("请先选择图片。");return;}
        if(prepared.length>ImageTools.MAX_UPLOAD){toast("图片超过 3 MiB，请缩小后上传。");return;}
        try{client();String uin=account.getText().toString().trim();if(!uin.matches("[1-9][0-9]{4,19}")){page(1);toast("请先在连接页填写 QQ 号和 Token。");return;}
            new AlertDialog.Builder(this).setTitle("更换 QQ 头像").setMessage("目标账号："+uin+"\n将上传当前预览对应的图片。透明和动画效果需要在 QQ 中核对。").setNegativeButton("取消",null).setPositiveButton("核对并上传",(d,w)->upload()).show();
        }catch(Exception e){page(1);failure(e);}
    }
    void upload(){
        try{NapCatClient c=client();String uin=account.getText().toString().trim();byte[] bytes=prepared;
            log("请求上传："+ImageTools.inspect(bytes).summary()+"；"+bytes.length+" 字节；SHA256="+ImageTools.hash(bytes).substring(0,16)+"。");
            task("正在核对账号并上传…",()->{c.upload(uin,bytes);return true;},ok->{log("接口返回成功（retcode=0）；实际显示待 QQ 核验。");status.setText("接口已接受，请到 QQ 核对");new AlertDialog.Builder(this).setTitle("接口返回成功").setMessage("请在 QQ 中刷新并检查实际头像。透明通道和动画播放仍以 QQ 显示为准。").setPositiveButton("知道了",null).show();});
        }catch(Exception e){failure(e);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null){if(request==EXPORT_IMAGE)pendingExport=null;return;}final Uri uri=data.getData();
        if(request==PICK){task("正在读取图片…",()->{try(InputStream in=getContentResolver().openInputStream(uri)){byte[] bytes=ImageTools.readLimited(in,ImageTools.MAX_INPUT);ImageTools.inspect(bytes);return bytes;}},bytes->{source=bytes;info=ImageTools.inspect(bytes);prepared=bytes;binding=true;original.setChecked(info.animated());opacity.setProgress(100);binding=false;updateEnabled();log("选择图片："+info.summary()+"；"+bytes.length+" 字节。");if(info.animated())display(bytes);else refresh();});}
        else if(request==EXPORT_IMAGE||request==EXPORT_LOG){final byte[] bytes=request==EXPORT_IMAGE?pendingExport:history.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);pendingExport=null;
            if(bytes==null){toast("图片已失效，请重新导出。");return;}task("正在导出…",()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("目标文件无法写入。");out.write(bytes);}return bytes.length;},n->{toast("已导出");log("导出完成，"+n+" 字节。");});}
    }
    void showLicense(){try(InputStream in=getAssets().open("THIRD_PARTY_NOTICES.txt")){String s=new String(ImageTools.readLimited(in,100000),java.nio.charset.StandardCharsets.UTF_8);new AlertDialog.Builder(this).setTitle("第三方许可").setMessage(s).setPositiveButton("关闭",null).show();}catch(Exception e){failure(e);}}
    @Override protected void onDestroy(){destroyed=true;worker.shutdownNow();super.onDestroy();}
    int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    static final class Checkerboard extends Drawable {
        final Paint p=new Paint();@Override public void draw(Canvas c){Rect r=getBounds();int step=Math.max(12,r.width()/16);for(int y=r.top;y<r.bottom;y+=step)for(int x=r.left;x<r.right;x+=step){p.setColor(((x-r.left)/step+(y-r.top)/step)%2==0?0xffe9e2e5:0xfff8f4f6);c.drawRect(x,y,Math.min(x+step,r.right),Math.min(y+step,r.bottom),p);}}
        public void setAlpha(int a){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.OPAQUE;}
    }
}
