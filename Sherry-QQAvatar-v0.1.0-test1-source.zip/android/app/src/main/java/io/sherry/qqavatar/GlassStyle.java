package io.sherry.qqavatar;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.os.SystemClock;
import android.view.*;
import android.widget.FrameLayout;
import java.util.ArrayList;

/** Shared animated optical backdrop. All sampling is local; no screen capture or new permissions. */
public final class GlassStyle extends FrameLayout {
    private static final String FIELD =
        "uniform float2 viewport; uniform float time; uniform float2 light;"+
        "float3 field(float2 p){float2 uv=p/max(viewport,float2(1.0));"+
        "float2 a=float2(0.13+0.15*sin(time*0.19),0.20+0.09*cos(time*0.21));"+
        "float2 b=float2(0.83+0.10*cos(time*0.15),0.44+0.16*sin(time*0.17));"+
        "float2 c=float2(0.25+0.18*sin(time*0.12),0.90+0.08*cos(time*0.16));"+
        "float3 col=float3(0.88,0.93,0.98);"+
        "col=mix(col,float3(0.65,0.72,0.98),0.78*exp(-dot(uv-a,uv-a)*8.0));"+
        "col=mix(col,float3(0.91,0.73,0.88),0.74*exp(-dot(uv-b,uv-b)*8.0));"+
        "col=mix(col,float3(0.56,0.86,0.82),0.65*exp(-dot(uv-c,uv-c)*6.0));"+
        "return col;}";
    private static final String GLASS=FIELD+
        "uniform float2 size; uniform float2 origin; uniform float radius; uniform float weight; uniform float pressed;"+
        "half4 main(float2 p){float2 n=(p-size*0.5)/max(size*0.5,float2(1.0));"+
        "float2 q=abs(p-size*0.5)-(size*0.5-radius);"+
        "float d=length(max(q,0.0))+min(max(q.x,q.y),0.0)-radius;"+
        "float rim=exp(-abs(d)/2.0);float inner=exp(-max(-d,0.0)/12.0);"+
        "float2 bend=n*(8.0+22.0*inner);"+
        "float3 col=field(origin+p+bend);"+
        "float3 red=field(origin+p+bend*1.14);float3 blue=field(origin+p+bend*0.86);"+
        "col=float3(red.r,col.g,blue.b);"+
        "col=mix(col,float3(1.0),0.40+0.14*weight+0.05*pressed);"+
        "float2 lp=(light-origin)/max(size,float2(1.0));"+
        "float sheen=exp(-length(p/size-lp)*2.4);"+
        "col+=0.07*sheen+rim*(0.10+0.18*max(-n.y,0.0));"+
        "col=mix(col,float3(0.56,0.66,0.92),rim*0.13*max(n.y,0.0));"+
        "return half4(half3(clamp(col,0.0,1.0)),1.0);}";
    private final ArrayList<Surface> surfaces=new ArrayList<>();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Object backdrop;
    private boolean running;
    private float time,lightX,lightY,targetX,targetY;
    private final long epoch=SystemClock.uptimeMillis();
    private final int[] location=new int[2];
    private final Runnable frame=new Runnable(){@Override public void run(){
        if(!running)return;
        time=(SystemClock.uptimeMillis()-epoch)/1000f;
        lightX+=(targetX-lightX)*0.12f;lightY+=(targetY-lightY)*0.12f;
        invalidate();for(Surface s:surfaces)if(s.owner.isShown())s.invalidateSelf();
        postDelayed(this,33);
    }};
    public GlassStyle(Context c){super(c);setWillNotDraw(false);
        if(Build.VERSION.SDK_INT>=33)backdrop=new RuntimeShader(FIELD+"half4 main(float2 p){float glow=0.006*exp(-length(p-light)/max(viewport.y,1.0));return half4(half3(field(p)+glow),1.0);}");
    }
    public void start(){if(!running){running=true;post(frame);}}
    public void stop(){running=false;removeCallbacks(frame);}
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);targetX=lightX=w*.24f;targetY=lightY=h*.12f;}
    @Override public boolean dispatchTouchEvent(android.view.MotionEvent e){targetX=e.getX();targetY=e.getY();return super.dispatchTouchEvent(e);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        if(Build.VERSION.SDK_INT>=33&&backdrop!=null&&c.isHardwareAccelerated()){RuntimeShader sh=(RuntimeShader)backdrop;uniforms(sh);paint.setShader(sh);c.drawPaint(paint);paint.setShader(null);}
        else{
            c.drawColor(0xffe4edf7);float w=getWidth(),h=getHeight();
            orb(c,w*(.2f+.13f*(float)Math.sin(time*.19)),h*.2f,w*.95f,0xffa8b8fa);
            orb(c,w*.92f,h*(.43f+.12f*(float)Math.sin(time*.17)),w,0xffe8c0df);
            orb(c,w*.25f,h*.96f,w*1.2f,0xff9fded2);
        }
    }
    private void orb(Canvas c,float x,float y,float r,int color){paint.setShader(new RadialGradient(x,y,Math.max(r,1),new int[]{color,color&0x00ffffff},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);}
    private void uniforms(RuntimeShader sh){if(Build.VERSION.SDK_INT>=33){sh.setFloatUniform("viewport",Math.max(getWidth(),1),Math.max(getHeight(),1));sh.setFloatUniform("time",time);sh.setFloatUniform("light",lightX,lightY);}}
    public Drawable surface(View owner,float radius,float weight){Surface s=new Surface(owner,radius,weight);surfaces.add(s);return s;}
    public void decorate(View v,float radius,float weight){v.setBackground(surface(v,radius,weight));v.setClipToOutline(true);v.setOutlineProvider(ViewOutlineProvider.BACKGROUND);v.setElevation(0);}
    final class Surface extends Drawable {
        final View owner;final float radius,weight;final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final RectF rect=new RectF();final int[] xy=new int[2];final Object shader;
        Surface(View owner,float radius,float weight){this.owner=owner;this.radius=radius;this.weight=weight;shader=Build.VERSION.SDK_INT>=33?new RuntimeShader(GLASS):null;}
        @Override public void draw(Canvas c){Rect bounds=getBounds();if(bounds.isEmpty())return;rect.set(bounds);float pressed=owner.isPressed()?1f:0f;
            if(Build.VERSION.SDK_INT>=33&&shader!=null&&c.isHardwareAccelerated()){
                RuntimeShader sh=(RuntimeShader)shader;uniforms(sh);owner.getLocationOnScreen(xy);GlassStyle.this.getLocationOnScreen(location);
                sh.setFloatUniform("size",bounds.width(),bounds.height());sh.setFloatUniform("origin",xy[0]-location[0],xy[1]-location[1]);
                sh.setFloatUniform("radius",radius);sh.setFloatUniform("weight",owner.isSelected()?1f:weight);sh.setFloatUniform("pressed",pressed);
                c.save();c.translate(bounds.left,bounds.top);p.setShader(sh);c.drawRoundRect(0,0,bounds.width(),bounds.height(),radius,radius,p);c.restore();p.setShader(null);
            }else{
                owner.getLocationOnScreen(xy);float t=time*.2f+(xy[1]/900f);
                int top=blend(0xfff6f7ff,0xffd8e1fa,.26f+.12f*(float)Math.sin(t));
                int bottom=blend(0xffe8f5f3,0xffe9d8ef,.42f+.18f*(float)Math.cos(t));
                p.setShader(new LinearGradient(0,rect.top,rect.right,rect.bottom,new int[]{top,0xfff4f6fc,bottom},null,Shader.TileMode.CLAMP));c.drawRoundRect(rect,radius,radius,p);p.setShader(null);
                p.setColor(Color.argb((int)(35+weight*36+pressed*20),255,255,255));c.drawRoundRect(rect,radius,radius,p);
            }
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(.8f,getResources().getDisplayMetrics().density*.8f));rect.inset(.7f,.7f);
            p.setShader(new LinearGradient(rect.left,rect.top,rect.right,rect.bottom,new int[]{0xfaffffff,0x45ffffff,0x60a0add6,0xe8ffffff},new float[]{0,.42f,.76f,1},Shader.TileMode.CLAMP));c.drawRoundRect(rect,radius,radius,p);p.setShader(null);p.setStyle(Paint.Style.FILL);
        }
        @Override public void getOutline(Outline outline){outline.setRoundRect(getBounds(),radius);}
        @Override public boolean isStateful(){return true;}
        @Override protected boolean onStateChange(int[] state){invalidateSelf();return true;}
        @Override public void setAlpha(int a){}@Override public void setColorFilter(ColorFilter f){}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
    private static int blend(int a,int b,float t){return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t),(int)(Color.green(a)*(1-t)+Color.green(b)*t),(int)(Color.blue(a)*(1-t)+Color.blue(b)*t));}
}
