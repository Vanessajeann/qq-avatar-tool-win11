package io.sherry.qqavatar;

import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** Only speaks to a user-configured OneBot HTTP server on the same phone. */
public final class NapCatClient {
    private final URI endpoint;
    private final String token;
    public NapCatClient(String address, String token) throws IOException {
        endpoint = validateEndpoint(address);
        this.token = token == null ? "" : token.trim();
        if (this.token.indexOf('\r') >= 0 || this.token.indexOf('\n') >= 0)
            throw new IOException("Token 不能包含换行。");
    }
    public static URI validateEndpoint(String address) throws IOException {
        try {
            URI u = new URI(address.trim());
            if (!"http".equals(u.getScheme()) || !"127.0.0.1".equals(u.getHost()) ||
                u.getUserInfo()!=null || u.getQuery()!=null || u.getFragment()!=null ||
                !(u.getPath().isEmpty() || "/".equals(u.getPath())) || u.getPort()<1 || u.getPort()>65535)
                throw new Exception();
            return new URI("http",null,"127.0.0.1",u.getPort(),"/",null,null);
        } catch (Exception e) { throw new IOException("请填写 http://127.0.0.1:端口/，使用 OneBot HTTP 端口，不是 WebUI 端口。"); }
    }
    public String checkAccount(String expected) throws IOException {
        if (expected == null || !expected.matches("[1-9][0-9]{4,19}")) throw new IOException("请输入需要更换头像的 QQ 号。");
        try {
            JSONObject data = call("get_login_info",null).optJSONObject("data");
            if (data==null || !expected.equals(data.optString("user_id")))
                throw new IOException("NapCat 登录账号与填写的 QQ 号不一致，已停止操作。");
            return expected;
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("登录信息无法解析，请确认 QQ 已登录。"); }
    }
    public void upload(String expected, byte[] image) throws IOException {
        if(image==null || image.length==0 || image.length>ImageTools.MAX_UPLOAD)
            throw new IOException("上传图片必须在 3 MiB 以内。");
        checkAccount(expected); // Recheck immediately before the only mutating call.
        call("set_qq_avatar",image);
    }
    private JSONObject call(String action, byte[] image) throws IOException {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)endpoint.resolve(action).toURL().openConnection(Proxy.NO_PROXY);
            c.setConnectTimeout(8000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(false);
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            if(!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
            // {"file":"base64:// + base64 + "} : calculate from literal bytes.
            byte[] prefix="{\"file\":\"base64://".getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(image==null?2:prefix.length+4*((image.length+2)/3)+2);
            try(OutputStream out=new BufferedOutputStream(c.getOutputStream())) {
                if(image==null) out.write("{}".getBytes(StandardCharsets.UTF_8));
                else {
                    out.write(prefix);
                    // wrap without closing the underlying request before the final JSON suffix.
                    OutputStream b64=Base64.getEncoder().wrap(new FilterOutputStream(out){@Override public void write(byte[] b,int off,int len) throws IOException { out.write(b,off,len); } @Override public void close() throws IOException { flush(); }});
                    b64.write(image); b64.close(); out.write('"'); out.write('}');
                }
            }
            int status=c.getResponseCode();
            if(status==401||status==403) throw new IOException("Token 验证失败，请使用 OneBot HTTP 服务的 Token。");
            if(status>=300 && status<400) throw new IOException("接口返回跳转，已停止。请核对 OneBot HTTP 端口。");
            if(status!=200) throw new IOException("接口返回 HTTP "+status+"，请核对 OneBot HTTP 端口和服务日志。");
            ByteArrayOutputStream body=new ByteArrayOutputStream();
            try(InputStream in=c.getInputStream()) {
                byte[] buffer=new byte[8192]; int n;
                while((n=in.read(buffer))!=-1){if(body.size()+n>1024*1024) throw new IOException("接口响应过大，已停止读取。请先在 QQ 核对头像结果。"); body.write(buffer,0,n);}
            }
            JSONObject result;
            try{ result=new JSONObject(body.toString("UTF-8")); }
            catch(Exception e){ throw new IOException("服务返回的不是有效 OneBot JSON，请核对端口，不能填写 WebUI 地址。"); }
            if(!result.has("retcode") || !result.has("status")) throw new IOException("服务返回内容不符合 OneBot 格式。");
            if(result.optInt("retcode",-1)!=0 || !"ok".equals(result.optString("status")))
                throw new IOException("接口 "+action+" 返回失败（"+result.optInt("retcode",-1)+"）："+
                    safeMessage(result.optString("message",result.optString("wording","请查看 NapCat 日志。")),token));
            return result;
        } catch(SocketTimeoutException e){throw new IOException(image==null?"连接超时，请确认 NapCat HTTP 服务已启动。":"上传请求超时，结果未确认。请先在 QQ 查看头像，不要立即重复上传。");}
        catch(IOException e){throw new IOException(safeMessage(e.getMessage(),token));}
        catch(Exception e){throw new IOException("本地接口通信失败，请检查服务、端口和 Token。");}
        finally{if(c!=null)c.disconnect();}
    }
    public static String safeMessage(String message,String token) {
        if(message==null||message.isEmpty())return "没有提供错误原因。";
        // Avoid processing megabytes of echoed image data in an error.
        String s=message.length()>4096?message.substring(0,4096):message;
        if(token!=null&&!token.isEmpty())s=s.replace(token,"[Token 已隐藏]");
        s=s.replaceAll("(?i)base64://[A-Za-z0-9+/=\\s]*","[图片数据已隐藏]");
        s=s.replaceAll("(?i)data:image/[^,]*,[A-Za-z0-9+/=\\s]*","[图片数据已隐藏]");
        s=s.replace('\r',' ').replace('\n',' ');
        return s.length()>400?s.substring(0,400)+"…":s;
    }
}
