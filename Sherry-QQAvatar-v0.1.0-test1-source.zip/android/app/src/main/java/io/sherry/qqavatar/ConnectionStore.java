package io.sherry.qqavatar;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Opt-in storage. No plaintext credentials or fallback cipher. */
public final class ConnectionStore {
    private static ConnectionStore device;
    public static synchronized ConnectionStore device(Context c){if(device==null)device=new ConnectionStore(c.getApplicationContext());return device;}
    static final String ALIAS="sherry.qqavatar.connection.v1";
    private final SharedPreferences prefs;
    private final Keys keys;
    public interface Keys { SecretKey get(boolean create)throws Exception; void delete()throws Exception; }
    public static final class Data {
        public final String endpoint,token,account;
        public Data(String endpoint,String token,String account){this.endpoint=endpoint;this.token=token;this.account=account;}
    }
    public ConnectionStore(Context c){this(c.getSharedPreferences("connection-v1",Context.MODE_PRIVATE),new DeviceKeys());}
    ConnectionStore(SharedPreferences prefs,Keys keys){this.prefs=prefs;this.keys=keys;}
    public synchronized boolean enabled(){return prefs.getBoolean("remember",false);}
    public synchronized void enable(){if(!prefs.edit().putBoolean("remember",true).commit())throw new IllegalStateException("无法保存设置。");}
    public synchronized void clear(){
        if(!prefs.edit().clear().commit())throw new IllegalStateException("无法清除保存的信息。");
        try{keys.delete();}catch(Exception ignored){/* Ciphertext is already removed. */}
    }
    public synchronized void save(Data data)throws Exception{
        if(!enabled())return;
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,keys.get(true));
        JSONObject plain=new JSONObject();plain.put("endpoint",data.endpoint);plain.put("token",data.token);plain.put("account",data.account);
        byte[] sealed=cipher.doFinal(plain.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        JSONObject envelope=new JSONObject();envelope.put("v",1);envelope.put("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP));envelope.put("data",Base64.encodeToString(sealed,Base64.NO_WRAP));
        if(!prefs.edit().putString("sealed",envelope.toString()).commit())throw new IllegalStateException("无法保存加密连接信息。");
    }
    public synchronized Data load()throws Exception{
        if(!enabled())return null;String saved=prefs.getString("sealed",null);if(saved==null)return null;
        JSONObject envelope=new JSONObject(saved);if(envelope.getInt("v")!=1)throw new IllegalStateException("保存格式不兼容。");
        byte[] iv=Base64.decode(envelope.getString("iv"),Base64.NO_WRAP);if(iv.length!=12)throw new IllegalStateException("保存数据无效。");
        SecretKey key=keys.get(false);if(key==null)throw new IllegalStateException("加密密钥已失效。");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));
        JSONObject plain=new JSONObject(new String(cipher.doFinal(Base64.decode(envelope.getString("data"),Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8));
        return new Data(plain.getString("endpoint"),plain.getString("token"),plain.getString("account"));
    }
    static final class DeviceKeys implements Keys {
        private KeyStore store()throws Exception{KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);return s;}
        public SecretKey get(boolean create)throws Exception{
            KeyStore s=store();SecretKey key=(SecretKey)s.getKey(ALIAS,null);if(key!=null||!create)return key;
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).setRandomizedEncryptionRequired(true).build());return generator.generateKey();
        }
        public void delete()throws Exception{store().deleteEntry(ALIAS);}
    }
}
