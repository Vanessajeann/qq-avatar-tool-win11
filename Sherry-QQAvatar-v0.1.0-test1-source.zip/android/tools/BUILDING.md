# 构建说明

解压后目录是仓库根目录结构：`android/` 为 Android 工程，`.github/workflows/android-apk.yml` 为云端流程。

本机安装 JDK 17、Gradle 8.11.1、Android SDK，配置 ANDROID_HOME。安装平台 35 和 build-tools 35.0.0。首次构建需要下载 Google/Maven Central 的依赖。

```sh
gradle -p android --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
python3 -m pip install Pillow==11.1.0
python3 android/tools/verify_apng.py
```

APK 默认输出 `android/app/build/outputs/apk/debug/app-debug.apk`。这是测试签名 APK，不是无签名 release 文件。

云端流程在 `android-apk` 分支推送时运行。可以把压缩包目录内容放入现有仓库的新分支 `android-apk`，保留原有 Windows 文件。流程执行单测、编译、Lint、独立 APNG 校验，成功后上传 APK、SHA256、签名信息和验证报告。

没有配置自动发布 Release 或自动上传真实 QQ；运行工作流不会更改用户头像。
