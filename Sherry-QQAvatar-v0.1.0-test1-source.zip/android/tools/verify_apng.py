"""Independent Pillow comparison: frame composition, durations, alpha and CRCs."""
from PIL import Image, ImageChops
from pathlib import Path
import struct, zlib
root = Path(__file__).resolve().parents[1] / 'app/build/qa'
for name in ('test.gif','partial.gif'):
    source, target = Image.open(root/name), Image.open(root/(name+'.png'))
    assert source.n_frames == target.n_frames
    assert source.size == target.size
    for i in range(source.n_frames):
        source.seek(i); target.seek(i)
        a, b = source.convert('RGBA'), target.convert('RGBA')
        assert a.getchannel('A').tobytes() == b.getchannel('A').tobytes(), (name,i,'alpha')
        # Invisible RGB components need not match. Composite on black for visible pixels.
        bg=Image.new('RGBA',a.size,(0,0,0,255))
        assert Image.alpha_composite(bg,a).tobytes() == Image.alpha_composite(bg,b).tobytes(), (name,i,'pixels')
        delay=source.info.get('duration',100)
        if delay<20: delay=100
        assert abs(delay-target.info['duration'])<.01, (name,i,'duration')
    data=(root/(name+'.png')).read_bytes(); pos=8; seq=0
    while pos<len(data):
        n=struct.unpack_from('>I',data,pos)[0]; kind=data[pos+4:pos+8]; block=data[pos+8:pos+8+n]
        assert zlib.crc32(kind+block)&0xffffffff == struct.unpack_from('>I',data,pos+8+n)[0]
        if kind in (b'fcTL',b'fdAT'):
            assert struct.unpack_from('>I',block)[0] == seq
            seq+=1
        pos+=n+12
    assert pos==len(data)
    print(f'{name}: {source.n_frames} frames, pixels, alpha, timing, sequence and CRCs passed')
